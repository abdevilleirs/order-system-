let cart = [];

// Simple encryption function (for demo purposes)
function encryptCode(code) {
    return btoa(code); // Base64 encoding for simplicity
}

// Login function
function login() {
    const code = document.getElementById("loginCode").value;

    if (encryptCode("123") === encryptCode(code)) {
        document.getElementById("loginScreen").classList.add("hidden");
        document.getElementById("shopScreen").classList.remove("hidden");
        document.getElementById("whatsappOptions").classList.remove("hidden"); // Show WhatsApp options
    } else if (encryptCode("123456") === encryptCode(code)) {
        document.getElementById("loginScreen").classList.add("hidden");
        document.getElementById("factoryScreen").classList.remove("hidden");
        displayOrders();  // Show orders for Factory Manager
    } else {
        alert("Invalid code. Please try again.");
    }
}

// Function to toggle between screens
function toggleScreen(target) {
    if (target === "shop") {
        document.getElementById("factoryScreen").classList.add("hidden");
        document.getElementById("shopScreen").classList.remove("hidden");
    } else if (target === "factory") {
        document.getElementById("shopScreen").classList.add("hidden");
        document.getElementById("factoryScreen").classList.remove("hidden");
        displayOrders();  // Update orders list when switching to Factory Manager view
    }
}

// Add item to cart
function addToCart() {
    const itemName = document.getElementById("itemName").value.trim();
    const quantity = document.getElementById("quantity").value;

    if (itemName && quantity > 0) {
        cart.push({ itemName, quantity });
        document.getElementById("itemName").value = ""; // Reset the item input
        document.getElementById("quantity").value = ""; // Reset the quantity input
        updateCartDisplay();
    } else {
        alert("Please enter an item name and a valid quantity.");
    }
}

// Update cart display
function updateCartDisplay() {
    const cartDisplay = document.getElementById("cartDisplay");
    cartDisplay.innerHTML = ""; // Clear existing display

    if (cart.length === 0) {
        cartDisplay.innerHTML = "<p>No items in cart.</p>";
        return;
    }

    cart.forEach((item) => {
        const cartItem = document.createElement("div");
        cartItem.innerHTML = `<p>${item.itemName} - Quantity: ${item.quantity} kg</p>`;
        cartDisplay.appendChild(cartItem);
    });
}

// Place order function
function placeOrder() {
    const shopID = document.getElementById("shopID").value.trim();
    const orderID = document.getElementById("orderID").value.trim();
    const orderDate = document.getElementById("orderDate").value;
    const deliveryDate = document.getElementById("deliveryDate").value;
    const deliveryTime = document.getElementById("deliveryTime").value;

    if (!shopID || !orderDate || !deliveryDate || !deliveryTime || cart.length === 0) {
        alert("Please fill out all fields and add items to cart before placing an order.");
        return;
    }

    // Save the order to localStorage (simulating a database)
    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    const newOrderID = orderID || new Date().getTime(); // Use provided Order ID or generate a new one
    orders.push({ orderID: newOrderID, shopID, orderDate, deliveryDate, deliveryTime, items: cart });
    localStorage.setItem("orders", JSON.stringify(orders));

    alert("Order placed successfully!");
    sendOrderToWhatsApp(shopID, orderDate, deliveryDate, deliveryTime, cart); // Send WhatsApp message
    cart = []; // Clear the cart after placing the order
    updateCartDisplay(); // Update cart display
}

// Search for orders by Order ID
function searchOrder() {
    const searchOrderID = document.getElementById("searchOrderID").value.trim();
    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    const orderList = document.getElementById("orderList");
    orderList.innerHTML = ""; // Clear existing orders

    if (searchOrderID) {
        const filteredOrders = orders.filter(order => order.orderID == searchOrderID);
        if (filteredOrders.length === 0) {
            orderList.innerHTML = "<p>No orders found with that Order ID.</p>";
            return;
        }

        filteredOrders.forEach((order) => {
            const orderItem = document.createElement("div");
            orderItem.className = "order-item";
            orderItem.innerHTML = `
                <h4>Order ID: ${order.orderID} (Shop ID: ${order.shopID})</h4>
                <p>Order Date: ${order.orderDate}</p>
                <p>Delivery Date: ${order.deliveryDate}</p>
                <p>Delivery Time: ${order.deliveryTime}</p>
                <p>Items:</p>
                <ul>
                    ${order.items.map(item => `<li>${item.itemName} - Quantity: ${item.quantity} kg</li>`).join('')}
                </ul>
                <button onclick="deleteOrder('${order.orderID}')">Delete Order</button>
                <hr>
            `;
            orderList.appendChild(orderItem);
        });
    } else {
        displayOrders(); // If no search term, display all orders
    }
}

// Display all orders (Factory Manager)
function displayOrders() {
    const orderList = document.getElementById("orderList");
    orderList.innerHTML = "";  // Clear existing orders

    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    if (orders.length === 0) {
        orderList.innerHTML = "<p>No orders found.</p>";
        return;
    }

    orders.forEach((order) => {
        const orderItem = document.createElement("div");
        orderItem.className = "order-item";
        orderItem.innerHTML = `
            <h4>Order ID: ${order.orderID} (Shop ID: ${order.shopID})</h4>
            <p>Order Date: ${order.orderDate}</p>
            <p>Delivery Date: ${order.deliveryDate}</p>
            <p>Delivery Time: ${order.deliveryTime}</p>
            <p>Items:</p>
            <ul>
                ${order.items.map(item => `<li>${item.itemName} - Quantity: ${item.quantity} kg</li>`).join('')}
            </ul>
            <button onclick="deleteOrder('${order.orderID}')">Delete Order</button>
            <hr>
        `;
        orderList.appendChild(orderItem);
    });
}

// Delete order by Order ID
function deleteOrder(orderID) {
    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    const updatedOrders = orders.filter(order => order.orderID !== orderID);
    localStorage.setItem("orders", JSON.stringify(updatedOrders));
    alert(`Order ID ${orderID} deleted successfully!`);
    searchOrder(); // Refresh the order list
}

// Send order details to WhatsApp
function sendOrderToWhatsApp(shopID, orderDate, deliveryDate, deliveryTime, items) {
    const whatsappNumber = document.getElementById("whatsappNumber").value;
    let message = `Order Summary:\nShop ID: ${shopID}\nOrder Date: ${orderDate}\nDelivery Date: ${deliveryDate}\nDelivery Time: ${deliveryTime}\nItems:\n`;
    
    items.forEach(item => {
        message += `${item.itemName} - Quantity: ${item.quantity} kg\n`;
    });

    const encodedMessage = encodeURIComponent(message);
    const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
    window.open(whatsappLink, "_blank");
}
